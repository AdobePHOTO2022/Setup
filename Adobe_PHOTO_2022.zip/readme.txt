1) Download the archive.
2) Unzip in new folder.
3) Password: grey22
4) Open setup file